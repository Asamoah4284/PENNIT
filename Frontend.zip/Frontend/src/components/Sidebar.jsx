import { Link, useLocation } from 'react-router-dom'
import { getUser } from '../lib/auth'

export default function Sidebar() {
    const user = getUser()
    const location = useLocation()
    const isWriter = user?.role === 'writer'
    const isActive = (path) => location.pathname === path

    if (isWriter) {
        return (
            <div className="sticky top-16 p-6 h-[calc(100vh-4rem)] overflow-y-auto">
                <nav className="space-y-1">
                    <SidebarLink to="/writers-dashboard" icon={<HomeIcon />} label="Overview" active={isActive('/writers-dashboard')} />
                </nav>
            </div>
        )
    }

    return (
        <div className="sticky top-16 p-6 h-[calc(100vh-4rem)] overflow-y-auto">
            <nav className="space-y-1">
                <SidebarLink to="/home" icon={<HomeIcon />} label="Home" active={isActive('/home')} />
                <SidebarLink to="/reader" icon={<StoriesIcon />} label="Discover" active={isActive('/reader')} />
                <SidebarLink to="/library" icon={<LibraryIcon />} label="Library" active={isActive('/library')} />
                <SidebarLink to="/profile" icon={<UserIcon />} label="Profile" active={isActive('/profile')} />
                <SidebarLink to="/stats" icon={<StatsIcon />} label="Stats" active={isActive('/stats')} />
            </nav>

            <div className="my-6 border-t border-stone-100"></div>

            <div>
                <h3 className="text-sm font-medium text-stone-500 mb-4 flex items-center gap-2">
                    <FollowingIcon />
                    Following
                </h3>
                <div className="space-y-3">
                    <p className="text-sm text-stone-500">Find writers and publications to follow.</p>
                    <Link to="/discover" className="text-sm font-medium text-stone-900 underline hover:no-underline">
                        See suggestions
                    </Link>
                </div>
            </div>
        </div>
    )
}

function SidebarLink({ to, icon, label, active }) {
    return (
        <Link
            to={to}
            className={`flex items-center gap-4 px-3 py-2.5 rounded-lg transition-colors ${active ? 'text-stone-900 font-semibold bg-stone-50' : 'text-stone-600 hover:bg-stone-50 hover:text-stone-900'}`}
        >
            <span className={active ? 'text-stone-900' : 'text-stone-400'}>{icon}</span>
            <span className="text-base">{label}</span>
        </Link>
    )
}

// Icons
function HomeIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
        </svg>
    )
}

function LibraryIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0 1 11.186 0Z" />
        </svg>
    )
}

function UserIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z" />
        </svg>
    )
}

function StoriesIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18a8.967 8.967 0 0 0-6 2.292m0-14.25v14.25" />
        </svg>
    )
}

function StatsIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
        </svg>
    )
}

function FollowingIcon() {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 19.128a9.38 9.38 0 0 0 2.625.372 9.337 9.337 0 0 0 4.121-.952 4.125 4.125 0 0 0-7.533-2.493M15 19.128v-.003c0-1.113-.285-2.16-.786-3.07M15 19.128v.106A12.318 12.318 0 0 1 8.624 21c-2.331 0-4.512-.645-6.374-1.766l-.001-.109a6.375 6.375 0 0 1 11.964-3.07M12 6.375a3.375 3.375 0 1 1-6.75 0 3.375 3.375 0 0 1 6.75 0Zm8.25 2.25a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z" />
        </svg>
    )
}
